package com.example.otpforwarder

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Telephony
import android.telephony.SmsMessage
import android.widget.Button
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.regex.Pattern

class MainActivity : AppCompatActivity() {

    companion object {
        private const val SMS_PERMISSION_REQUEST = 100
        // Your Make.com webhook URL
        private const val MAKE_WEBHOOK_URL = "https://hook.eu2.make.com/bnooc4nm64eu13l89hcq9f25tjvztiam"
    }

    private lateinit var autoForwardSwitch: Switch
    private lateinit var lastOtpTextView: TextView
    private lateinit var testButton: Button
    private var smsReceiver: SmsReceiver? = null
    private val executorService: ExecutorService = Executors.newSingleThreadExecutor()
    private val httpClient = OkHttpClient()

    // Patterns to detect OTP in SMS
    private val otpPatterns = arrayOf(
        Pattern.compile("\\b(\\d{4,8})\\b.*(?:OTP|otp|code|Code|PIN|pin|verification|verify)", Pattern.CASE_INSENSITIVE),
        Pattern.compile("(?:OTP|otp|code|Code|PIN|pin|verification|verify).*\\b(\\d{4,8})\\b", Pattern.CASE_INSENSITIVE),
        Pattern.compile("(?:use|enter).*\\b(\\d{4,8})\\b", Pattern.CASE_INSENSITIVE),
        Pattern.compile("\\b(\\d{4,8})\\b.*(?:expire|valid|minutes)", Pattern.CASE_INSENSITIVE),
        Pattern.compile("\\b(\\d{4,8})\\b", Pattern.CASE_INSENSITIVE) // Fallback for any 4-8 digit number
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize views
        autoForwardSwitch = findViewById(R.id.autoForwardSwitch)
        lastOtpTextView = findViewById(R.id.lastOtpTextView)
        testButton = findViewById(R.id.testButton)

        // Initialize SMS receiver
        smsReceiver = SmsReceiver()

        // Check and request SMS permissions
        checkSmsPermissions()

        // Set up test button
        testButton.setOnClickListener { testMakeForwarding() }

        // Set up auto-forward switch
        autoForwardSwitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (checkSmsPermissions()) {
                    registerSmsReceiver()
                    Toast.makeText(this, "OTP forwarding enabled via Make.com", Toast.LENGTH_SHORT).show()
                } else {
                    autoForwardSwitch.isChecked = false
                }
            } else {
                unregisterSmsReceiver()
                Toast.makeText(this, "OTP forwarding disabled", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun checkSmsPermissions(): Boolean {
        return if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS),
                SMS_PERMISSION_REQUEST
            )
            false
        } else {
            true
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == SMS_PERMISSION_REQUEST) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permissions granted", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "SMS permissions required for OTP forwarding", Toast.LENGTH_LONG).show()
                autoForwardSwitch.isChecked = false
            }
        }
    }

    private fun registerSmsReceiver() {
        val filter = IntentFilter(Telephony.Sms.Intents.SMS_RECEIVED_ACTION)
        filter.priority = 1000 // High priority to intercept SMS
        registerReceiver(smsReceiver, filter)
    }

    private fun unregisterSmsReceiver() {
        try {
            smsReceiver?.let { unregisterReceiver(it) }
        } catch (e: IllegalArgumentException) {
            // Receiver not registered
        }
    }

    private fun testMakeForwarding() {
        val testOtp = "123456"
        val testMessage = "Test OTP forwarding: Your verification code is $testOtp. Do not share this code."
        val testSender = "TEST"

        Toast.makeText(this, "Sending test OTP to Make.com...", Toast.LENGTH_SHORT).show()
        forwardOtpViaMake(testOtp, testMessage, testSender)
    }

    private fun forwardOtpViaMake(otp: String, originalMessage: String, sender: String) {
        runOnUiThread {
            lastOtpTextView.text = "🔄 Forwarding OTP: $otp from $sender"
        }

        executorService.execute {
            try {
                // Create current timestamp
                val currentTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

                // Create payload for Make.com
                val payload = JSONObject().apply {
                    put("otp", otp)
                    put("original_message", originalMessage)
                    put("sender", sender)
                    put("timestamp", currentTime)
                    put("device_model", android.os.Build.MODEL)
                    put("device_brand", android.os.Build.BRAND)
                    put("android_version", android.os.Build.VERSION.RELEASE)
                }

                val body = RequestBody.create(
                    "application/json; charset=utf-8".toMediaType(),
                    payload.toString()
                )

                val request = Request.Builder()
                    .url(MAKE_WEBHOOK_URL)
                    .post(body)
                    .addHeader("Content-Type", "application/json")
                    .addHeader("User-Agent", "OTP-Forwarder-Android/1.0")
                    .build()

                httpClient.newCall(request).execute().use { response ->
                    runOnUiThread {
                        if (response.isSuccessful) {
                            lastOtpTextView.text = "✅ OTP sent: $otp (Make.com)"
                            Toast.makeText(this@MainActivity, "OTP sent via Make.com! Check your email in 1-10 seconds.", Toast.LENGTH_LONG).show()
                        } else {
                            lastOtpTextView.text = "❌ Failed: ${response.code}"
                            Toast.makeText(this@MainActivity, "Make.com request failed: ${response.code}\nResponse: ${response.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                }

            } catch (e: IOException) {
                runOnUiThread {
                    lastOtpTextView.text = "❌ Network error"
                    Toast.makeText(this@MainActivity, "Network error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    lastOtpTextView.text = "❌ Unexpected error"
                    Toast.makeText(this@MainActivity, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun extractOtpFromMessage(message: String): String? {
        // Clean the message first
        val cleanMessage = message.trim()

        for (pattern in otpPatterns) {
            val matcher = pattern.matcher(cleanMessage)
            if (matcher.find()) {
                val otp = matcher.group(1)
                if (otp != null && otp.length >= 4 && otp.length <= 8) {
                    // Additional validation: avoid phone numbers and long numbers
                    if (isLikelyOtp(otp, cleanMessage)) {
                        return otp
                    }
                }
            }
        }
        return null
    }

    private fun isLikelyOtp(otp: String, message: String): Boolean {
        val lowerMessage = message.lowercase()

        // Skip if it looks like a phone number (10 digits starting with specific patterns)
        if (otp.length == 10 && (otp.startsWith("0") || otp.startsWith("1"))) {
            return false
        }

        // Skip if message contains keywords that suggest it's not an OTP
        val nonOtpKeywords = listOf("amount", "balance", "credit", "debit", "payment", "invoice", "bill")
        if (nonOtpKeywords.any { lowerMessage.contains(it) }) {
            return false
        }

        // Check for OTP-related keywords
        val otpKeywords = listOf("otp", "code", "pin", "verification", "authenticate", "login", "verify", "confirm", "security")
        return otpKeywords.any { lowerMessage.contains(it) }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterSmsReceiver()
        executorService.shutdown()
    }

    // SMS Broadcast Receiver
    private inner class SmsReceiver : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (!autoForwardSwitch.isChecked) {
                return
            }

            if (Telephony.Sms.Intents.SMS_RECEIVED_ACTION == intent.action) {
                val bundle = intent.extras
                if (bundle != null) {
                    val pdus = bundle.get("pdus") as Array<*>?
                    if (pdus != null) {
                        for (pdu in pdus) {
                            try {
                                val smsMessage = SmsMessage.createFromPdu(pdu as ByteArray)
                                val messageBody = smsMessage.messageBody
                                val sender = smsMessage.originatingAddress

                                // Log the received SMS for debugging
                                runOnUiThread {
                                    Toast.makeText(this@MainActivity, "SMS received from: $sender", Toast.LENGTH_SHORT).show()
                                }

                                // Extract OTP from message
                                val otp = extractOtpFromMessage(messageBody)

                                if (otp != null) {
                                    // Forward OTP to Make.com
                                    forwardOtpViaMake(otp, messageBody, sender ?: "Unknown")
                                } else {
                                    runOnUiThread {
                                        lastOtpTextView.text = "📱 SMS received but no OTP detected"
                                    }
                                }

                            } catch (e: Exception) {
                                runOnUiThread {
                                    Toast.makeText(this@MainActivity, "Error processing SMS: ${e.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}